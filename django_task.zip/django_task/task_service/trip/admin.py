from django.contrib import admin
from .models import trips
# Register your models here.
admin.site.register(trips)
