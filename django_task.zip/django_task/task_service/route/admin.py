from django.contrib import admin
from .models import route
# Register your models here.
admin.site.register(route)